from run import start_project

start_project()