from drps.run import start_project

start_project()